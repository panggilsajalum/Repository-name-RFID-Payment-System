<?php
// projekTA/api/config.php

// Matikan laporan error mysqli agar tidak bocor ke output publik
mysqli_report(MYSQLI_REPORT_OFF);

// ====== SESUAIKAN BAGIAN INI DENGAN SERVER MYSQL KAMU ======
$DB_HOST = 'localhost';   // bisa juga '127.0.0.1'
$DB_USER = 'punp4156_koperasi_pp';        // user default XAMPP
$DB_PASS = 'tugasakhir';            // password MySQL-mu (kosong kalau default)
$DB_NAME = 'punp4156_koperasi_pp'; // nama database dari dump
// ===========================================================

$mysqli = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($mysqli->connect_errno) {
  // Jika dipanggil dari /api/*, balas JSON; selain itu tampilkan HTML rapi
  $is_api = (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/api/') !== false);
  if ($is_api) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
      'status'  => 'error',
      'message' => 'Gagal konek database: ' . $mysqli->connect_error,
    ]);
  } else {
    http_response_code(500);
    echo '<!doctype html><meta charset="utf-8"><style>
            body{font-family:system-ui;background:#0f172a;color:#e2e8f0;padding:24px}
            pre{background:#0b1220;padding:16px;border-radius:12px;overflow:auto}
          </style>
          <h2>DB connect error</h2>
          <pre>' . htmlspecialchars($mysqli->connect_error, ENT_QUOTES, 'UTF-8') . '</pre>';
  }
  exit;
}

// Set charset & timezone biar konsisten dengan dump
$mysqli->set_charset('utf8mb4');
$mysqli->query("SET time_zone = '+07:00'");

// Alias supaya file lain yang masih pakai $conn tetap jalan
$conn = $mysqli;
// Tambahkan di paling bawah projekTA/api/config.php
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'])) {
  header('Content-Type: text/plain; charset=utf-8');
  echo "DB connection: " . ($mysqli && $mysqli->ping() ? "OK" : "FAILED") . "\n";
  echo "Host: $DB_HOST\nUser: $DB_USER\nDB: $DB_NAME\n";
  exit;
}
