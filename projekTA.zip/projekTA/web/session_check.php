<?php
session_start();
if (!isset($_SESSION['ping'])) $_SESSION['ping'] = 1;
else $_SESSION['ping']++;

echo 'PHPSESSID: ' . (session_id() ?: '(kosong)') . "<br>";
echo 'Counter: ' . $_SESSION['ping'] . "<br>";
echo 'Headers sent? ' . (headers_sent() ? 'YES' : 'NO');
